<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liklik_diwai";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch images and descriptions from the database
$sql = "SELECT img_name, img_SME FROM images_table";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo '<div class="image-item">';
        echo '<img src="./' . $row["img_name"] . '" alt="Image">';
        echo '<p>' . $row["img_SME"] . '</p>';
        echo '</div>';
    }
} else {
    echo "No images found.";
}

$conn->close();
?>
